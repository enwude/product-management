package labs.pm.app;

import org.junit.jupiter.api.Test;

class ShopTests {

	@Test
	void test() {
		new Shop();
		Shop.main(null);
	}

}
